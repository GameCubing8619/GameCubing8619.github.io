Hi i am GameCubing8619 And this is my submission to the HH hollween contest 
down below is any notes/ how to run




Ok so for the notes there is random spawns for the enemys and treasures. 
and that is pretty much it
also on some spawns the starting cam is a bit weird bc one u readujust it or move it will be fine
And Lastly On The Third Floor THe Best Cam angle is keybord key D


how to run

get a og pikmin 2 iso then put inside same folder as patcher and then drag into patch.bat

and that is all thnak u for reading